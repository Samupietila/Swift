// TEHTÄVÄ 2

enum Pelitulos {
   case Yli, Ali, Osuma
    
    
}
class YliAli {
   var alaraja: Int
   var ylaraja: Int
   let numero: Int
   var arvaukset: [Int] = []
   
   init(alaraja: Int, ylaraja: Int) {
       self.alaraja = alaraja
       self.ylaraja = ylaraja
       self.numero = (alaraja...ylaraja).randomElement() ?? 0
   }
   
    func arvaa(arvaus: Int) -> Pelitulos{
       if arvaus < self.numero{

           self.arvaukset.append(arvaus)
           return Pelitulos.Ali
       }
       else if arvaus > self.numero{

           self.arvaukset.append(arvaus)
           return Pelitulos.Yli
       }
       else {

           self.arvaukset.append(arvaus)
           return Pelitulos.Osuma
       }
   }
}
func pelaapeli() -> Int {
    let peli = YliAli(alaraja:1, ylaraja: 1000)
    var osuma = false
    var ar = peli.alaraja
    var yr = peli.ylaraja
    while osuma == false {
            var arvausJono = Array(ar...yr)
            var keskiIndex = arvausJono.count / 2
            var arvaus = peli.arvaa(arvaus: arvausJono[keskiIndex])
            if arvaus == Pelitulos.Osuma {
                //print("Arvausten määrä: \(peli.arvaukset.count)")
                osuma = true
            }
            else if arvaus == Pelitulos.Ali {
                ar = arvausJono[keskiIndex] + 1
            }
            else {
                yr = arvausJono[keskiIndex] - 1
            }
            
         }
    return peli.arvaukset.count
    }

var a = pelaapeli()


func pelaaPeleja() {
    var arvausjono: [Int] = []
    for i in 0...10000 {
        var a = pelaapeli()
        arvausjono.append(a)
    }
    var sum = 0
    arvausjono.forEach { number in
        sum += number
    }
    var arvausKa = sum / arvausjono.count
    print("Arvausten keskiarvo: \(arvausKa)")
}

var b = pelaaPeleja()
